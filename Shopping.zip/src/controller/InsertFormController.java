package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.MemberDAO;

public class InsertFormController implements Controller {
	
	@Override
	public MyView process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("InsertFormController MyView 실행2....");
		
		MemberDAO dao = new MemberDAO();
		int custno = dao.getMaxCustNo();
		request.setAttribute("custno", custno);
		return new MyView("/view/memberInsert.jsp");
	}
}
