package controller;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/member/*")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private HashMap<String, Controller> controllerMap = new HashMap<>();
       
	
    public FrontController() {
        super();
    }

    
	public void init(ServletConfig config) throws ServletException {
		controllerMap.put("/member/insertForm", new InsertFormController());
		controllerMap.put("/member/memberInsert", new MemberInsertController());
		controllerMap.put("/member/memberList", new MemberListController());
		controllerMap.put("/member/updateForm", new UpdateFormController());
		controllerMap.put("/member/memberupdate", new MemberUpdateController());
		controllerMap.put("/member/moneyList", new MoneyListController());
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String path = requestURI.substring(contextPath.length());
		
		Controller controller = controllerMap.get(path);
		if(controller == null) {
			response.setStatus(HttpServletResponse.SC_NOT_FOUND);
			return;
		}
		
		MyView view = controller.process(request, response);
		view.render(request, response);
	}
}